def zostaw_bp():
    return None